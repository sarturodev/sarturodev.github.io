let totalDuration=0;let currentDuration=0;let ocurrences=0;let lastDuration;let timeToToggle=0;let resetVdStops=!1;window.document.body.onload=()=>{if(window.document.URL.indexOf("https://www.baymack.com/videos")>-1||window.document.URL.indexOf("https://www.baylom.com/videos")>-1||window.document.URL.indexOf("https://www.snuckls.com")>-1){setTimeout(()=>{let currentDurationSpan=document.querySelector(".video-page-current-duration");let totalDurationSpan=document.querySelector(".video-page-total-duration");let nextVideoBtn=document.querySelector("#nextVideo");checkStatus()},5000)}
if(window.document.URL.indexOf("https://www.youtube.com/embed/")>-1){if(window.document.URL.indexOf("www.baymack.com")>-1||window.document.URL.indexOf("iv_load_policy=3&disablekb=1&loop=0&start=0")>-1){let clickedToPlay=!1;document.body.addEventListener("click",()=>{resetVdStops=vdcount();if(!clickedToPlay){setTimeout(()=>{checkVersion();parseVideo()},1500);clickedToPlay=!0}})
function parseVideo(){let onFirstFire=!0;let onSecondFire=!1;let onThirdFire=!1;let timeToStop=18;let forcePaused=!1;let duration;let currentSeconds=0;let lastSeconds=0;try{let videoTag=document.querySelector(".video-stream");chrome.runtime.onMessage.addListener(function(request,sender,sendResponse){if(request.duration){duration=request.duration}});if(videoTag){chrome.runtime.sendMessage({ready:!1,stopped:!1},function(response){return!0});currentSeconds=0;videoTag.currentTime=0;if(videoTag.playbackRate==1){videoTag.playbackRate=2}
videoTag.addEventListener("timeupdate",()=>{if((videoTag.currentTime>=timeToStop)){if(onFirstFire||onSecondFire||onThirdFire){forcePaused=!0;if(onFirstFire){onSecondFire=!0;onFirstFire=!1}else if(onSecondFire){onSecondFire=!1;onThirdFire=!0}else if(onThirdFire){onThirdFire=!1;if(currentSeconds){currentSeconds-=10}}
videoTag.pause();setTimeout(()=>{videoTag.play();forcePaused=!1},1800)}
timeToStop*=2}
if(videoTag.currentTime>=videoTag.duration){if(chrome.runtime.connect())
chrome.runtime.sendMessage({ready:!1,stopped:!0},function(response){return!0})}
if(resetVdStops){onFirstFire=!0;onSecondFire=!1;onThirdFire=!1;timeToStop=18;resetVdStops=!1}});try{videoTag.addEventListener("pause",()=>{if(!forcePaused){if(chrome.runtime.connect())
chrome.runtime.sendMessage({ready:!1,stopped:!0},function(response){return!0})}})}catch(e){};try{videoTag.addEventListener("play",()=>{if(chrome.runtime.connect())
chrome.runtime.sendMessage({ready:!1,stopped:!1},function(response){return!0})})}catch(e){}}}catch(e){}}
function vdcount(){if(chrome.runtime.connect())
chrome.runtime.sendMessage({vdcount:!0},function(response){return!0});return!0}}}
if(window.document.URL=="https://www.baymack.com/entry"||window.document.URL=="https://www.baylom.com/entry"){setTimeout(()=>{let nextBtn=document.querySelector(".back a");if(nextBtn){nextBtn.click()}},1500);chrome.runtime.sendMessage({ready:!1,stopped:!1},function(response){return!0})}}
function searchVideo(doc){let video=doc.querySelector("video");if(video){return video}}
function checkStatus(){let videoCategory,rcp,nextVideo;setInterval(()=>{videoCategory=document.querySelector(".video-category");rcp=document.body.querySelector(".captchaDivs");nextVideo=document.body.querySelector("#nextvideo");postAnswering=document.body.querySelector(".post-answering");if(videoCategory){if(videoCategory.style.display!="none")
chrome.runtime.sendMessage({ready:!0,stopped:!1},function(response){return!0})}
if(rcp){if(rcp.style.display!="none")
chrome.runtime.sendMessage({ready:!0,stopped:!1},function(response){return!0})}
if(nextVideo){if(nextVideo.style.display!="none"){if(window.document.URL.indexOf("https://www.snuckls.com")==-1){setTimeout(()=>{if(postAnswering){if(postAnswering.style.display!="none")nextVideo.click()}},3200)}}}},1000)}
function checkVersion(){if(!chrome.runtime.versionChecked){chrome.runtime.sendMessage({versionChecking:!0},function(response){return!0})}}
